<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Post;
use App\Comment;

use App\Events\PostComment;


class CommentController extends Controller
{
    public function store(Post $post)
    {
    	$this->validate(request(),[
    		'body' => 'required|min:10'
    	]);
    	//return \Auth::user()->id;

    	$post->addComment(request('body'));
    	// Comment::Create([
    	// 	'post_id' => $post->id,
    	// 	'body' => request('body'),
    	// 	'user_id' => \Auth::user()->id,
    	// ]);

    	// session()->flsah() holds session for only one time to the page it is redirected.
    	session()->flash('message', ' Comments has been submitted successfully.');

    	// session() holds message throughout the user session
    	//session('message', 'global messge');

        event(new PostComment([
            'name' => 'testng the event thread'
        ]));

    	return back();

    }
}
