<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use Auth;
use Carbon\Carbon;

use App\Mail\PostCreated;
use App\Mail\PostCreatedAgain;


class PostController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth')->except([
			'index',
			'show'
		]);
	}


    public function index()
    {
    	// called to the custome scope "scopeFilter" in post  model
    	// $posts = Post::latest()
    	// 		->filter(request(['month','year']))
    	// 		->get();

    	// $posts = Post::latest();

    	// if($month = request('month')){
    	// 	$posts->whereMonth('created_at', Carbon::parse($month)->month);
    	// }

    	// if($year = request('year')){
    	// 	$posts->whereYear('created_at', $year);
    	// }

    	// $posts = $posts->get();


    	// set in static method in post model
    	//$archives = Post::archives();

    	//return $archives;
    	$posts = Post::latest()->get();
    	return view('posts.index', compact('posts'));

    }


    public function show(Post $post)
    {
    	//$post = Post::find($post);
    	return view('posts.show', compact('post'));
    }


    public function create()
    {
    	return view('posts.create');
    }

    public function store(Request $request)
    {
    	$this->validate(request(),[
    		'title' => 'required|min:5|max:50',
    		'body' => 'required|min:10',
            'tag' => 'required',
    	]);

       // return $request;

    	$post = new Post;

    	$post->title = $request->title;
    	$post->body = $request->body;
    	$post->user_id = auth()->id();

    	$post->save();

        foreach ($request->tag as $tag ) {
            $post->tags()->attach($tag);
        }

    	// email with hardcoded css
    	// \Mail::to(Auth::user())->send(new PostCreated($post));

    	// emails with laravel components
    	\Mail::to(Auth::user())->send(new PostCreatedAgain($post));


    	// auth()->user()->publish(
    	// 	new Post([
    	// 		request('title'),
    	// 		request('body')
    	// 	])
    			
    	// );

    	// Post::Create([
    	// 	'title' => $request->title,
    	// 	'body' => $request->body,
    	// 	'user_id' => auth()->id(),
    	// ]);

    	return redirect('/');
    }
}
