<?php

namespace App\Listeners;

use App\Events\PostComment;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class CheckSpam
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostComment  $event
     * @return void
     */
    public function handle(PostComment $event)
    {
        dd("Checking for spam");
    }
}
