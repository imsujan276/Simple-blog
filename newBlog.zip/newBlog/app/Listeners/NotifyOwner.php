<?php

namespace App\Listeners;

use App\Events\PostComment;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyOwner
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PostComment  $event
     * @return void
     */
    public function handle(PostComment $event)
    {
        var_dump($event->thread['name']);
    }
}
