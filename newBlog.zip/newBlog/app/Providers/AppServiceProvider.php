<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        \Schema::defaultStringLength(191);

        //global variable accessible from all pages
         view()->share('global_tags', \App\Tag::select('id','name')->get());

        // global variable declaration for layouts/sidebar
        \View::composer('layouts.sidebar', function($view){


            $archives = \App\Post::archives();
            $tags = \App\Tag::has('posts')->pluck('name');

            $view->with(compact('archives', 'tags' ));
        });


    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        \App::singleton('App\Billing\Stripe', function(){
            return new \App\Billing\Stripe(config('services.stripe.secret'));
        });
    }
}
