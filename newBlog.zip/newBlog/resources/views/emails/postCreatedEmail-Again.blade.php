@component('mail::message')
# Post Uploaded


@component('mail::panel')
	<strong>Title : </strong> {{ $post->title }}
@endcomponent

@component('mail::button', ['url' => ''])
View Post
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
