<p>Dear {{ $post->user->name }}</p>

<h1> Your post with the following title been submitted </h1>
<hr>
<h3>{{ $post->title }} </h3>