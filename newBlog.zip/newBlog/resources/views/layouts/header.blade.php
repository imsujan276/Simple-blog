        <div class="blog-masthead">
          <div class="container">
            <nav class="nav blog-nav">
              <a class="nav-link active" href="/">Home</a>
              <a class="nav-link" href="/posts/create">New Post</a>

              @guest
                  <a href="{{ route('login') }}" class="nav-link">Login</a>
                  <a href="{{ route('register') }}" class="nav-link">Register</a>
              @else
                <a class="nav-link pull-right" href="{{ route('logout') }}"
                                              onclick="event.preventDefault();
                                                       document.getElementById('logout-form').submit();">
                    @if(Auth::check())       
                      {{ Auth::user()->name }} -Logout
                    @endif
                 </a>
                 @endguest
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
            </nav>
          </div>
        </div>

        <div class="blog-header">
          <div class="container">
            <h1 class="blog-title">The Bootstrap Blog</h1>
            <p class="lead blog-description">An example blog template built with Bootstrap.</p>
          </div>
        </div>