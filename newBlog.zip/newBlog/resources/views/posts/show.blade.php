@extends('layouts.master')


@section('content')

            <div class="col-sm-8 blog-main">

            	@if($msg = session('message'))

            		<div class="alert alert-success" role="alert">
            			{{ $msg }}
            		</div>

            	@endif

              <div class="blog-post">
                <h2 class="blog-post-title">{{ $post->title }}</h2>
                <p class="blog-post-meta"> By: <a href="#">Mark</a> 
                	{{ $post->created_at->diffForHumans() }}  
                </p>

                @if(count($post->tags))
                	Tags : 
                	@foreach($post->tags as $tag)
                		<a href="/posts/tags/{{ $tag->name }}">
                			{{ $tag->name }} 
                		</a>
                	@endforeach
                	<br>
                	<br>
                	
                @endif

                <p>
                	{{ $post->body }}
                </p>
                <hr>

                <div class="comments">
                	<h3>Comments </h3>
                	<ul class="list-group">
	                	@foreach($post->comments->sortByDesc('created_at') as $comment)
	                		<li class="list-group-item">
	                			<strong>
	                				{{ $comment->created_at->diffForHumans() }}: 
	                			</strong>
									 {{ ucfirst($comment->body) }}	
	                		</li>
	                	@endforeach
                	</ul>
                </div>

                <hr>

                <form method="POST" action="/posts/{{ $post->id }}/comment">

				{{ csrf_field() }}

				  <div class="form-group">
				    <textarea name="body" id="body" class="form-control" placeholder="Your Comment"></textarea>
				  </div>

				  <button type="submit" class="btn btn-info">Comment</button>
				</form>


				@include('layouts.errors')


              </div><!-- /.blog-post -->

            </div><!-- /.blog-main -->

 
@endsection
