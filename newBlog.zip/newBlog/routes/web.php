<?php

/*
service container -> geting the secret key of stripe

This kind of service provders are not practically used in route file.
This should be available globally 
So, this method is registered in AppServiceProvider.php
*/

// App::singleton('App\Billing\Stripe', function(){

// 	return new \App\Billing\Stripe(config('services.stripe.secret'));
// });

//print_r(resolve('App\Billing\Stripe'));

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();



	Route::get('/home', 'HomeController@index')->name('home');

	Route::get('/', 'PostController@index');

	Route::get('/posts/create', 'PostController@create');

	Route::post('/posts', 'PostController@store');

	Route::get('/posts/{post}', 'PostController@show');




	Route::post('/posts/{post}/comment', 'CommentController@store');

	Route::get('/posts/tags/{tag}', 'TagController@show');