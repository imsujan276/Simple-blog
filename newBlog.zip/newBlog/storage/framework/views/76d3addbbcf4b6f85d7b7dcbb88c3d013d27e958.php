<?php $__env->startComponent('mail::message'); ?>
# Post Uploaded


<?php $__env->startComponent('mail::panel'); ?>
	<strong>Title : </strong> <?php echo e($post->title); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
View Post
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
