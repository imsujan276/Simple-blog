<?php $__env->startSection('content'); ?>

            <div class="col-sm-8 blog-main">

            	<?php if($msg = session('message')): ?>

            		<div class="alert alert-success" role="alert">
            			<?php echo e($msg); ?>

            		</div>

            	<?php endif; ?>

              <div class="blog-post">
                <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
                <p class="blog-post-meta"> By: <a href="#">Mark</a> 
                	<?php echo e($post->created_at->diffForHumans()); ?>  
                </p>

                <?php if(count($post->tags)): ?>
                	Tags : 
                	<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<a href="/posts/tags/<?php echo e($tag->name); ?>">
                			<?php echo e($tag->name); ?> 
                		</a>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	<br>
                	<br>
                	
                <?php endif; ?>

                <p>
                	<?php echo e($post->body); ?>

                </p>
                <hr>

                <div class="comments">
                	<h3>Comments </h3>
                	<ul class="list-group">
	                	<?php $__currentLoopData = $post->comments->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                		<li class="list-group-item">
	                			<strong>
	                				<?php echo e($comment->created_at->diffForHumans()); ?>: 
	                			</strong>
									 <?php echo e(ucfirst($comment->body)); ?>	
	                		</li>
	                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</ul>
                </div>

                <hr>

                <form method="POST" action="/posts/<?php echo e($post->id); ?>/comment">

				<?php echo e(csrf_field()); ?>


				  <div class="form-group">
				    <textarea name="body" id="body" class="form-control" placeholder="Your Comment"></textarea>
				  </div>

				  <button type="submit" class="btn btn-info">Comment</button>
				</form>


				<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


              </div><!-- /.blog-post -->

            </div><!-- /.blog-main -->

 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>