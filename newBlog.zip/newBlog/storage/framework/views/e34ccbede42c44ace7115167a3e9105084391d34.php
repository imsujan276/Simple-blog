<p>Dear <?php echo e($post->user->name); ?></p>

<h1> Your post with the following title been submitted </h1>
<hr>
<h3><?php echo e($post->title); ?> </h3>